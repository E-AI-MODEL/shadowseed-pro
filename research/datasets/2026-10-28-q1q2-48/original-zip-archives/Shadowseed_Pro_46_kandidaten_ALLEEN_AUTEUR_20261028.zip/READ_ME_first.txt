Shadowseed Pro research only. AUTHOR-ONLY, do not publish.

46 original not_atomic detector candidates with source and host context. These are not 46 verified valuable seeds. No automatic seed birth, Gate promotion, or human semantic judgment.
The original source sha256 is 0a5094e38ab2fdcf8c68dc8d6a3c75d29eeffd49e1f6c8e138589ed73ca36bbf.
The public research code and review protocol are at https://github.com/E-AI-MODEL/shadowseed-pro/pull/261.
Files:
- public_summary.json: mechanical aggregate and caveats (text-safe)
- PRIVATE_46_candidate_observations.csv: original texts and provenance
- PRIVATE_unjudged_reinspection_queue.json: full prior host contexts per candidate, all review fields blank
